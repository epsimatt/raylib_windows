#include "raylib.h"

#define TARGET_FPS 60

#define DEFAULT_WIDTH 768
#define DEFAULT_HEIGHT 512

#define FONT_SIZE 72

const char* message = "hello, world!";

/* ���� ȭ���� ������Ʈ�Ѵ�. */
void UpdateCurrentScreen(void);

int main(void) {
    InitWindow(DEFAULT_WIDTH, DEFAULT_HEIGHT, "raylib_example");
    SetTargetFPS(TARGET_FPS);

    while (!WindowShouldClose())
        UpdateCurrentScreen();

    return 0;
}

/* ���� ȭ���� ������Ʈ�Ѵ�. */
void UpdateCurrentScreen(void) {
    BeginDrawing();

    ClearBackground(BLACK);

    DrawRectangleGradientV(
        0,
        0,
        DEFAULT_WIDTH,
        DEFAULT_HEIGHT,
        (Color) { 20, 163, 142, 255 },
        (Color) { 171, 255, 202, 255 }
    );
    
    DrawText(
        message,
        (DEFAULT_WIDTH - MeasureText(message, FONT_SIZE)) / 2,
        (DEFAULT_HEIGHT - FONT_SIZE) / 2,
        FONT_SIZE,
        WHITE
    );

    EndDrawing();
}